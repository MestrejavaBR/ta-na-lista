const abrir = document.getElementById('abrir-modal');
const fechar = document.getElementById('fechar-modal');
const modal = document.getElementById('modal');

abrir.addEventListener('click', (e) => {
  e.preventDefault();
  modal.classList.add('mostrar');
});

fechar.addEventListener('click', () => {
  modal.classList.remove('mostrar');
});
