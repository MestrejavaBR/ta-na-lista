
document.getElementById("campoEmail").addEventListener("input", function () {
  let botao = document.getElementById("botaoEmail");

  if (this.value.length > 3 && this.value.includes("@")) {
    botao.disabled = false;
    botao.style.background = "#00c853";
  } else {
    botao.disabled = true;
    botao.style.background = "#ccc";
  }
});


document.getElementById("botaoEmail").onclick = function () {
  document.getElementById("tela1").classList.remove("ativa");
  document.getElementById("tela2").classList.add("ativa");
};


document.getElementById("campoSenha").addEventListener("input", function () {
  let botao = document.getElementById("botaoSenha");

  if (this.value.length >= 6) {
    botao.classList.remove("desativado");
    botao.classList.add("ativo");
  } else {
    botao.classList.remove("ativo");
    botao.classList.add("desativado");
  }
});


function voltar(tela) {
  if (tela === 2) {
    document.getElementById("tela2").classList.remove("ativa");
    document.getElementById("tela1").classList.add("ativa");
  }
}
